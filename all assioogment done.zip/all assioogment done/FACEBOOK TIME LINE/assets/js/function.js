/**
 * set Alert funtion
 * @param {*} msg 
 * @param {*} type 
 * @returns 
 */

 const setAlert = (msg,type = 'danger') => {

    return ` <p class="alert alert-${type} d-flex justify-content-between">${msg} <button data-bs-dismiss="alert" class="btn-close"></button></p>`
}



/**
 * create local storage data funciton
 * @param {*} key 
 * @param {*} value 
 */

const createLsData = (key, value) => {

    let data = [];

    if(localStorage.getItem(key)){

        data = JSON.parse(localStorage.getItem(key));

    }

    data.push(value);


    localStorage.setItem(key , JSON.stringify(data));
}




/**
 * rede local storage data function
 * @param {*} key 
 * @returns 
 */


const redeLsData = (key) => {

    if(localStorage.getItem(key)){

        return JSON.parse(localStorage.getItem(key))

    } else{
        return false 
    }
}


/**
 * ubdata local storage data fuction 
 * @param {*} key 
 * @param {*} array 
 */

const ubDateLsData = (key , array) => {

    localStorage.setItem(key , JSON.stringify(array));

}