const post_form = document.getElementById('post_form');
const edit_form = document.getElementById('edit_form');
const msg = document.querySelector('.msg');
const all_post = document.querySelector('.all-post');



const gateAllProduct = () => {

    const data = redeLsData('fb_post');


    if (!data) {

    }

    if (data) {
        let list = '';

        data.reverse().map(item => {
            list += `
            <div class="post_timeline_ariya my-4">
                            <div class="card">
                                <div class="card-body">
                                    <div class="post_auth_ariya">
                                        <div class="usere_info">
                                            <img src="${item.aphoto}" alt="">
                                           <div class="ditels">
                                            <span>${item.aname}</span>
                                            <span>2 h . <i class="fa-solid fa-earth-americas"></i></span>
                                           </div>
                                        </div>
                                        <div class="dropdown">
                                            <a class=" dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fa-solid fa-ellipsis"></i>
                                            </a>
                                          
                                            <ul class="dropdown-menu">
                                              <li><a class="dropdown-item edit_post"  edit_id =${item.id}  href="#edit_modal" data-bs-toggle="modal">Edit</a></li>
                                              <li><a class="dropdown-item delete_post" post_id = ${item.id} href="#">Delete</a></li>
                                              <li><a class="dropdown-item" href="#">Something else here</a></li>
                                            </ul>
                                          </div>
                                    </div>
                                    <div class="post_content my-2">
                                        <p>${item.content}</p>
                                       
                                    </div>
                                </div>
                                <img src="${item.photo}" alt="">
    
                                <div class="like_airya">
                                    <div class="like_list">
                                        <i class="fa-solid fa-thumbs-up"></i>
                                        <span>Like</span>
                                    </div>
                                    <div class="like_list">
                                    <i class="fa-solid fa-comment"></i>
                                        <span>Comment</span>
                                    </div>
                                    <div class="like_list">
                                    <i class="fa-solid fa-share"></i>
                                        <span>Shere</span>
                                    </div>
    
                                </div>
    
                            </div>
                        </div>


            `
        })

        all_post.innerHTML = list;
    }
}

gateAllProduct()

post_form.onsubmit = (e) => {

    e.preventDefault()

    const form_data = new FormData(e.target);
    const data = Object.fromEntries(form_data.entries());
    const {
        aname,
        aphoto,
        content,
        photo
    } = Object.fromEntries(form_data.entries());

    const randomId = Math.floor(Math.random() * 100000) + '_' + Date.now()

    if (!aname || !aphoto || !content || !photo) {
        msg.innerHTML = setAlert('all filds are riqurd !!');

    } else {
        msg.innerHTML = setAlert('Data stable', 'success')


        createLsData('fb_post', {
            ...data,
            id: randomId
        })

        e.target.reset()
        gateAllProduct()
    }

}





all_post.onclick = (e) => {

    e.preventDefault();

    /*post delete */

    if (e.target.classList.contains('delete_post')) {

        //gate post id 

        const postId = e.target.getAttribute('post_id');

        //gate all post

        const posts = redeLsData('fb_post');

        const deleteData = posts.filter(data => data.id !== postId);


        ubDateLsData('fb_post', deleteData)

        gateAllProduct()
    }



    if (e.target.classList.contains('edit_post')) {

        const postId = e.target.getAttribute('edit_id');

        const posts = redeLsData('fb_post');


        const editData = posts.findIndex(data => data.id == postId);
        const { aname, aphoto, content, photo, id } = posts[editData];


        edit_form.innerHTML = `
      
        <div class="my-3">
                            <label for="">atur name</label>
                            <input value="${aname}" name="aname" type="text" class="form-control">
                            <input name="id" value = "${id}" type="hidden" class="form-control">
                        </div>
                        <div class="my-3">
                            <label for="">atur photo</label>
                            <input name="aphoto" value = "${aphoto}" type="text" class="form-control">
                            
                        </div>
                        
                        <div class="my-3">
                            <label for="">content</label>
                            <textarea name="content" class="form-control" name="" id="" cols="30" rows="3">${content}</textarea>
                        </div>
                        <div class="my-3">
                        <img style="height: 250px; width: 100% ; object-fit: contain;" src="${photo}" alt="">
                    </div>
                        <div class="my-3">
                            <label for="">photo</label>
                            <input name="photo" value ="${photo}" type="text" class="form-control">
                        </div>
                        <div class="my-3">
                            <input type="submit" class="btn btn-primary w-100" value="post now">
                        </div>

        `




    }



}


edit_form.onsubmit = (e) => {

    e.preventDefault();



    const form_data = new FormData(e.target);
    const {aname, aphoto, id, content, photo}  = Object.fromEntries(form_data.entries());


  const  all_data = redeLsData('fb_post');


    const index = all_data.findIndex(data => data.id == id);


   all_data[index] = {aname, aphoto, id, content, photo};



   ubDateLsData('fb_post', all_data)


   gateAllProduct();

   
}


