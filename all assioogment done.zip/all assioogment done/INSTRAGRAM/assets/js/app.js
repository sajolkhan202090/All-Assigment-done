
const post_form = document.getElementById('post_form');
const msg       = document.querySelector('.msg');
const all_post  = document.querySelector('.all-post');







const gateAllproduct = () => {

    const data = redeLsData('ins_post')


    if(data){
        let list = '';
        data.map(item => {
            list += `
            
            <div class="post-ariya">
            <div class="card active-card my-3">
                <div class="card-body">

                    <div class="row">
                        <div class="col-md-10">
                            <div class="post-detals">
                                <img src="${item.aphoto}" alt="">
                                <span>${item.aname}</span>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="post-icon">
                                <div class="dropdown">
                                    <a class=" dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fa-solid fa-ellipsis"></i>
                                    </a>
                                  
                                    <ul class="dropdown-menu">
                                      <li><a class="dropdown-item edit_post" edit_id = ${item.id} href="#edit_post" data-bs-toggle="modal">Edit</a></li>
                                      <li><a class="dropdown-item delete_post" Post_id = ${item.id} href="#">Delete</a></li>
                                      <li><a class="dropdown-item" href="#">Something else here</a></li>
                                    </ul>
                                  </div>
                                  
                            </div>
                           
                        </div>
                        <div class="post_content my-2">
                        <p>${item.content}</p>
                       
                    </div>
                    </div>
                </div>
                <img class="w-100" src="${item.photo}" alt="">
            </div>
        </div>

            `
        })

        all_post.innerHTML = list ;
    }
   
}


gateAllproduct()



post_form.onsubmit = (e) =>{

    e.preventDefault()

    const form_data = new FormData(e.target);
    const data      = Object.fromEntries(form_data.entries());
    const {aname , aphoto, content, photo}      = Object.fromEntries(form_data.entries());
    const randomId = Math.floor(Math.random() * 10000) +'_'+ Date.now ();


    if(!aname || !aphoto || !content || !photo ){
        msg.innerHTML= setAlert();

    }else{
        msg.innerHTML= setAlert('Data stable', 'success');

        createLsData('ins_post', {...data, id : randomId});

        e.target.reset()
        gateAllproduct()
        
    
    }

   ;

}




all_post.onclick = (e) => {
    
    e.preventDefault()

    if(e.target.classList.contains('delete_post')){
      
        const postId = e.target.getAttribute('post_id');

        const posts = redeLsData('ins_post');

        const delete_post = posts.filter( data => data.id !== postId);


        ubDateLsData('ins_post', delete_post);

        gateAllproduct()
    }


    if(e.target.classList.contains('edit_post')){

        
    }

    

}