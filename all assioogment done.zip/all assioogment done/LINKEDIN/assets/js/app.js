
const post_form  = document.getElementById('post_form');
const edit_form  = document.getElementById('edit_form');
const msg        = document.querySelector('.msg');
const all_post        = document.querySelector('.all-post');







const gateAllPost = () => {

    let data = readLsData('linkdin_post');
    
    if(data){
        let list = '';

        data.reverse().map( item => {

            list += `
            <div class="linkdin-time-line py-3">
            <div class="card">
                <div class="card-body">
                    <div class="auth-info">
                        <img src="${item.aphoto}" alt="">
                       <div class="auth-content">
                        <span>${item.aname}</span><br>
                        <p>2h.</p>
                        <div class="auth-icon">
                            <div class="dropdown">
                                <a class=" dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fa-solid fa-ellipsis"></i>
                                </a>
                              
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                 
                                  <li><a class="dropdown-item delete_post" delete_id = ${item.id} href="#">Delete</a></li>
                                  <li><a class="dropdown-item edit_post" edit_id = ${item.id} href="#edit_modal" data-bs-toggle="modal" href="#">Edit</a></li>
                                </ul>
                              </div>
                        </div>
                       </div>
                       <p class="mt-4 p-2">${item.content}</p>
                      
                    </div>
                </div>
                <img class=" post-img" src="${item.photo}" alt="">
            </div>
        </div>

            `
        })

        all_post.innerHTML = list ;
    }
    

}

gateAllPost()



post_form.onsubmit = (e) => {

    e.preventDefault()
    
    // gate from data 

    const form_data = new FormData(e.target);
    const data      = Object.fromEntries(form_data.entries());
    const { aname, aphoto, content, photo}      = Object.fromEntries(form_data.entries());

    const randomId = Math.floor(Math.random() * 100000) + '_' + Date.now();

    if( !aname || !aphoto || !content){

        msg.innerHTML = setAlert();

    } else{

        msg.innerHTML = setAlert('Data stable', 'success');
        e.target.reset();

        createLsData('linkdin_post', {...data, id : randomId})
        gateAllPost()
    }

}



all_post.onclick = (e) => {

    e.preventDefault()

    if(e.target.classList.contains('delete_post')){

        const postId = e.target.getAttribute('delete_id');

        const posts = readLsData('linkdin_post');

        const delete_post = posts.filter(data => data.id != postId)

        ubDateLsData('linkdin_post', delete_post);
        gateAllPost();
    }

    if(e.target.classList.contains('edit_post')){

        const postId = e.target.getAttribute('edit_id');

        const posts = readLsData('linkdin_post');

        const edit_data = posts.findIndex(data => data.id == postId);

        const { aname, aphoto, content, photo, id} = posts[edit_data];

        edit_form.innerHTML = `
        
        <div class="my-3">
                            <label for="#">Auth_Name</label>
                            <input name="aname" value="${aname}"  type="text" class="form-control">
                            <input type="hidden" name="id" value="${id}"   class="form-control">
                        </div>
                        <div class="my-3">
                            <label for="#">Auth_Phots</label>
                            <input name="aphoto" value="${aphoto}" type="text" class="form-control">
                        </div>
                        <div class="my-3">
                            <label for="#">Content</label>
                          <textarea  name="content" class="form-control" id="" cols="30" rows="10">${content}</textarea>
                        </div>
                        <div class="my-3">
                            <img style="object-fit:contain ; height: 200px; width: 100%;" src="${photo}" alt="">
                        </div>
                        <div class="my-3">
                            <label for="#">Phots</label>
                            <input name="photo" value="${photo}" type="text" class="form-control">
                        </div>
                        <div class="my-3">
                            <input  type="submit" class="btn btn-primary w-100" value="Post Now">
                        </div>

        `

    }
}




edit_form.onsubmit = (e) => {

    e.preventDefault();

    const from_data = new FormData(e.target);
    const {aname, aphoto, content, photo, id}  = Object.fromEntries(from_data.entries())

    
    const all_post = readLsData('linkdin_post');

    const index = all_post.findIndex(data => data.id == id);

    all_post[index]={aname, aphoto, content, photo, id}


    ubDateLsData('linkdin_post', all_post)

    gateAllPost()



}