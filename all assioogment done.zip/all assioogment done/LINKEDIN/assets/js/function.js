
//sete aleret function 

/**
 * 
 * @param {*} msg 
 * @param {*} type 
 * @returns 
 */

const setAlert = ( msg = 'All filds are riqurd !' , type = 'danger') => {

    return `
    <p class="alert alert-${type} d-flex justify-content-between">${msg}<button class="btn-close" data-bs-dismiss="alert"></button></p>
    `
}


/**
 * createLsData
 * @param {*} key 
 * @param {*} value 
 */

const createLsData = (key , value) => {

    let data = [];

    if(localStorage.getItem(key)){

        data = JSON.parse(localStorage.getItem(key))
    }

    data.push(value)

    localStorage.setItem(key, JSON.stringify(data))
}




const readLsData = (key) => {

    if(localStorage.getItem(key)){

        return JSON.parse(localStorage.getItem(key))

    } else{
        return false 
    }
}





/**
 * ubdata local storage data fuction 
 * @param {*} key 
 * @param {*} array 
 */

 const ubDateLsData = (key , array) => {

    localStorage.setItem(key , JSON.stringify(array));

}